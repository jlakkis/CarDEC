from .CarDEC_API import CarDEC_API

print("Waluigi")